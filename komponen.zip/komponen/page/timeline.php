<div class="container">
                                  
                  
                    <div id="content">

        <h3 class="text-center mt-100" style="font-family: 'Comic Sans MS', cursive;">Short Story Of Activities in 2023</h3>
                          
    
                        <ul class="timeline">
                            <li class="event" data-date="UAS dan Liburan">
                                <h3>Januari</h3>
                                <div class="timeline-icon"><i class="fa fa-book"></i><i class="fa fa-shopping-bag "></i></div>
                              
                              <p>-Tahun baruan dirumah teman
                                -Nonton bioskop
                                -mengikuti UAS di kampus Universitas muhammadiyah banten. </p>
                            </li>
                            <li class="event" data-date="Masuk Semester 2 ">
                                <h3>Februari</h3>
                                <div class="timeline-icon"><i class="fa fa-university"></i></div>
                                <p>Aktif Mengikuti kegiatan kuliah
                                 </p>
                            </li>
                            <li class="event" data-date="Promosi Kampus">
                                <h3>Maret</h3>
                                <div class="timeline-icon"><i class="fa fa-bus"></i></div>
                                
                                <p>promosi ke sekolah sekolah untuk mengundang acara Futsal
                                    -Selebihnya mengikuti kegiatan kuliah</p>
                            </li>
                            <li class="event" data-date="Puasa dan Lebaran">
                               
                                <h3>April</h3>
                                <div class="timeline-icon"><i class="fa fa-moon-o "></i>
                              
                               
                                <p>Melaksanakan Puasa-bukber with frend-merayakan hari raya idul fitri</p>
                            </li>
                            <li class="event" data-date="Semester 2">
                                <h3>Mei</h3>
                                 <div class="timeline-icon"><i class="fa fa-book"></i>
                              
                               
                                <p>Awal masuk semester 2</p>
                            </li>
                            <li class="event" data-date="UAS">
                                <h3>Juni</h3>
                                <div class="timeline-icon"><i class="fa fa-book"></i>
                              
                                <p>Mengikuti kegiatan UAS,mempelajari materi yang sudah diajarkan.</p>
                            </li>
                            <li class="event" data-date="Libur Kuliah dan mudik">
                                <h3>Juli</h3>
                                 <div class="timeline-icon"><i class="fa fa-ticket"></i><i class="fa fa-bus    "></i></div>
                              
                                <p>libur kuliah,langsung mudik ke rumah saudara. </p>
                            </li>
                            <li class="event" data-date="Kerja">
                                <h3>Agustus</h3>
                                <div class="timeline-icon"><i class="fa fa-money"></i></div>
                                
                                <p>Kerja jadi Admin Shopee</p>
                            </li>
                            <li class="event" data-date="Masuk Semester 3">
                                <h3>September</h3>
                                <div class="timeline-icon"><i class="fa fa-university"></i></div>
                                
                                <p>Masuk kuliah Semester 3,mengikuti kegiatan MASTA&PKKMB Universitas Muhamadiyah Banten </p>
                            </li>
                            <li class="event" data-date="Sosialisasi">
                                <h3>Oktober</h3>
                                <div class="timeline-icon"><i class="fa fa-bus "></i></div>
                                
                                <p>Sosialisasi di SMA 6 memberikan materi tentang "Bullying" </p>
                            </li>
                            <li class="event" data-date="Seminar,panitia DAD">
                                <h3>November</h3>
                                <div class="timeline-icon"><i class="fa fa-microphone  "></i></div>
                                
                                <p>mengikuti acara seminar Public Speaking bersama Vice President NET TV dan Mempersiapkan untuk acara DAD</p>
                            </li>
                            <li class="event" data-date="DAD,Panitia,Mudik">
                                <h3>Desember</h3>
                                 <div class="timeline-icon"><i class="fa fa-moon-o"></i><i class="fa fa-graduation-cap  "></i></div>
                              
                                <p>mengikuti DAD (Darul Arqam Dasar),Panitia Wisuda Universitas Muhammadiyah Banten dan malam akhir tahun bersama keluarga.</p>
                            </li>
                        </ul>
                    </div>
                
    </div>
</div>