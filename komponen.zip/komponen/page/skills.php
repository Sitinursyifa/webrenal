<section class="mh-skills" id="mh-skills">
            <div class="container">
                <div class="row section-separator">
                    <div class="section-title text-center col-sm-12">
                        <!--<h2>Skills</h2>-->
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-skills-inner">
                            <div class="mh-professional-skill wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                <h3>Technical Skills</h3>
                                <div class="each-skills">
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">delphi</div>
                                                <div class="percentagem-num">60%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 78%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">marketing</div>
                                                <div class="percentagem-num">85%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 46%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">php</div>
                                                <div class="percentagem-num">20%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 38%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">css</div>
                                                <div class="percentagem-num">30%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 17%;"></div>
                                            </div>
                                        </div>
                                    </div>                                    
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">design</div>
                                                <div class="percentagem-num">80%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 17%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-professional-skills wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s">
                            <h3>Professional Skills</h3>
                            <ul class="mh-professional-progress" >
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="95"></div>
                                    <div class="pr-skill-name">Communication</div>
                                </li>
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="95"></div> 
                                    <div class="pr-skill-name">Team Work</div>
                                </li>
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="80"></div>
                                    <div class="pr-skill-name">Project Management</div>
                                </li> 
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="80"></div>
                                    <div class="pr-skill-name">Creativity</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        