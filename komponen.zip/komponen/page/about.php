<section class="mh-about" id="mh-about ">
            <div class="container">
                <div class="row section-separator">
                    <div class="col-sm-12 col-md-6 ">
                        <div class="mh-about-img shadow-2 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                            <img src="assets/images/ab-img.png" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-about-inner">
                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">About Me</h2>
                            <p class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Hello, I’m Siti Nursyifa bisa dipanggil syifa,saya seseorang yang mempunyai sifat kepekaan terhadap keadaan di sekitar,bertanggung jawab dari hal terkecil,disiplin,menyukai hal baru dan berani memulai,berani mengambil keputusan,mudah berintreaksi dengan seseorang.Hal ini juga mampu menarik seseorang untuk berkerjasama dalam bisnis saya yaitu bisnis oriflame,dan yang terakhir saya seseorang yang menyukai dan memperbanyak relasi.
                            

                            </p>
                            <div class="mh-about-tag wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                <br>
                                
                                <ul>
                                    <li><span>Nama:Syifa </span></li>
                                    <li><span>Tempat,Tanggal lahir: Lebak,23 Agustus 2003</span></li>
                                    <li><span>alamat : Tangerang,Indonesia</span></li>
                                    <li><span>Status : Lajang</span></li>

                
                                </ul>
                                
                                
                                </br>
                            
                                
                                

                            </div>
                            <a href="https://drive.google.com/file/d/1vv8OU1Lw_zdsV5lrGNUSv7-x_vsEIoOz/view?usp=sharing" class="btn btn-fill wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">Download CV DISINI<i class="fa fa-download"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        